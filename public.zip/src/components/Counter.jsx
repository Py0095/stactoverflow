import { useReducer } from "react"

export default function Counter({ count }) {
    const initialState = {score: count}

  const reducer = (state, action) => {
    switch (action.type) {
      case "AJOUTE":
        return { score: state.score + 1 }
      case "RETIRE":
        return { score: state.score - 1 }
      default:
        return state
    }
  }

  const [state, dispatch] = useReducer(reducer, initialState)

  return (
    <div>
      <button onClick={() => dispatch({ type: "AJOUTE" })}>+</button>
      <label>{state.score}</label>
      <button onClick={() => dispatch({ type: "RETIRE" })}>-</button>
    </div>
  );
}
