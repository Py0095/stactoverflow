import Counter from './Counter'
export default function Reponse({ reponse , efase}) {
  
  return (
    <div>
      <h3>{reponse.answer}</h3>
      <Counter count={reponse.score}/>
      <button onClick={() => efase(reponse.id)}>Efase</button>
    </div>   );
}
