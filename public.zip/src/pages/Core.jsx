import React from "react";
import Header from "../components/Headers";
import Footer from "../components/Footer";
import Main from '../components/Main'

class Core extends React.Component {
  render() {
  
    return (
      <>
      <Header />
      <Main />
      <Footer />
      </>
    );
  }
}

export default Core;
