import React from "react";
import { useRef } from "react";


export default function Filter({filter,sort}) {
    // const sort = useRef('')



const onsortChanged=(event)=>{
  // console.log(event.target.value)
  sort(event.target.value)
}

const onfilterChanged=(event)=>{

      filter(event.target.value)
    }

  return (
    <form className="d-flex" role="search">
    <select name="filter" id="" onChange={onfilterChanged}>
      <option value="All">All</option>
      <option value="Active">Active</option>
      <option value="Inactive">Inactive</option>
    </select>
  
    <select name="sort" id="" onChange={onsortChanged}>
      <option value="Recent">Recent</option>
      <option value="Popular">Popular</option>
      <option value="Hot">Hot</option>
    </select>
    <button className="btn btn-outline-success" type="submit" onClick={(e)=>{e.preventDefault()
   console.log('clicked!!!')
    }
  }>
      Search
    </button>
  </form>
  );
}


