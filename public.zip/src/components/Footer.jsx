import React from 'react';
// import styles from '../components/footer.module.css';

export default function Footer(props) {
  return (
    // <!-- FOOTER -->
    <footer className="container">
      <p className="float-end"><a href="https://getbootstrap.com/docs/5.3/examples/carousel/#">Back to top</a></p>
      <p>© 2017–2022 Company, Inc. · <a href="https://getbootstrap.com/docs/5.3/examples/carousel/#">Privacy</a> · <a href="https://getbootstrap.com/docs/5.3/examples/carousel/#">Terms</a></p>
    </footer>
  )
}




































// className Footer extends React.Component
// {
//   render()
//   {
//     return (
//         <footer>
//             <div>All rights reserved © {this.props.group} 2023</div>
//         </footer>
//     )
//   }
// }

// Footer.defaultProps={
//   group:'Code9 className'
// }



// export default Footer;

