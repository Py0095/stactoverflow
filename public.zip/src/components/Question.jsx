import Reponse from "./Reponse";
import Counter  from './Counter';
import { useState } from "react";
// import Filter from './Filter'


export default function Question({ kesyon,efase }) {
  const [answers, setAnswers]= useState(kesyon.answers);

  // const [kesyon,setKesyon]=useState(kesyon)

  const efaseReponse = (id) => {
    const newAnswers = answers.filter((el) => el.id !== id)
    setAnswers(newAnswers)
  }

  
  


  return (
    <div>
      {/* <Filter /> */}
      <br/><br/>

        <br/>
      <h2>{kesyon.question}</h2>
      <span>{kesyon.date}</span><br/>
      <Counter count={kesyon.score} />
      <button onClick={() => efase(kesyon.id)}>Efase</button>
      <hr/>
      <strong>Total Reponse: {answers.length}</strong>
      <ul>
        {answers.map(res => <Reponse key={res.id} reponse={res} efase={efaseReponse} />)}
      </ul>
     {kesyon.tags.map((e)=><a href="#">|li tag {e}|</a>)} 
      <hr />
    </div>
  );
}
