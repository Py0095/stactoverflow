import React, { useState } from "react";
import Data from './data'
import Question from "./Question";
import Filter from "./Filter";



export default function Main(){

  const [data, setData] = useState(Data)

  const [filterValue,setfilterValue] = useState("All")
  const[sortValue,setSortvalue] = useState('Recent')

  const  efaseData = (id) => {
      const newKesyon = data.filter((el)=> el.id !== id)
      setData(newKesyon)
  }

  let filterData = data.filter((el)=>{
      if (filterValue ==='Active') 
        return el.status==='active'
      else if( filterValue === 'Inactive')
        return el.status==='deleted'
      else
        return el
  }
  )

  let sortData = filterData.filter((el)=>{
    if (sortValue ==='Recent') 
      return filterData.sort((a,b)=>a.date > b.date)
    else if( sortValue === 'Popular')
    return filterData.sort((a,b)=>a.score > b.score)
    else if(sortValue==='Hot')
    return filterData.sort((a,b)=>a.answers.length > b.answers.length)
    else
      return filterData
}
)



function sort1(sortValue) {
  alert(sortValue)
  setSortvalue(sortValue)
}

console.log(sortData)
function filter1(filterValue) {
  // alert(filterValue)
  setfilterValue(filterValue)
}
console.log(filterData)
console.log(sortData)
   
    return(
    <div>
      <br/><br/><br/>
      <Filter  filter={filter1} sort={sort1}/>
      {
        sortData.map(kesyon => <Question key={kesyon.id} kesyon={kesyon}  efase={efaseData}/>)
      }
     
    </div>
  )
}





























